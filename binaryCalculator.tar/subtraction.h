#ifndef SUBTRACTION_H
#define SUBTRACTION_H
#include "linkedList.h"
typedef struct Node Node;
typedef Node* List;

Number subtractTwoLinkedLists(Number L1,Number L2);
#endif

