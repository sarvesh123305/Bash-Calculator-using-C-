gcc -c main.c binaryCalculator.c


