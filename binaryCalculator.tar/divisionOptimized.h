// #include "linkedList.h"
#include "multiplication.h"
Number divideOptimizedTwoLinkedLists(Number,Number);