#ifndef POWER_H
#define POWER_H
#include "multiplication.h"
#endif
Number powerOfTwoLinkedLists(Number,Number);
Number powerOptimized(Number x,Number y);