// #include "linkedList.h"
#include "addition.h"
#include "subtraction.h"

Number multiply(Number,Number);