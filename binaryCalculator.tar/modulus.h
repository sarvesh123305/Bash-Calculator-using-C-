#ifndef MODULUS_H
#define MODULUS_H
#include "divisionOptimized.h" 
#endif
Number modulusOfTwoLinkedLists(Number firstNo,Number secondNo);