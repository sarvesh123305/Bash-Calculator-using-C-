clear
gcc main.c infixEvaluation.c linkedList.c addition.c characterStack/stack.c numberStack/stack.c subtraction.c multiplication.c divisionOptimized.c modulus.c power.c
./a.out
